#include "stm32l4xx.h"

#include "peripherals.h"

/* Enable both half-bridges to drive the motor */
void Peripheral_GPIO_EnableMotor(void)
{
	return;
}

/* Drive the motor in both directions */
void Peripheral_PWM_ActuateMotor(int32_t vel)
{
	return;
}

/* Read the counter register to get the encoder state */
int16_t Peripheral_Timer_ReadEncoder(void)
{
	return 0;
}
